// Uploads the student roster (student ID -> route + bus) to Firebase.
//
//   node import-students.js students.csv --dry-run    check the file only
//   node import-students.js students.csv              add/update students
//   node import-students.js students.csv --replace    replace the WHOLE roster
//
// Setup: npm install, then put serviceAccountKey.json next to this file
// (Firebase console > Project settings > Service accounts > Generate new private key)
// and set FIREBASE_DATABASE_URL (or edit DATABASE_URL below). Never share that key.

const fs = require("fs");

const DATABASE_URL = process.env.FIREBASE_DATABASE_URL || "https://YOUR-PROJECT-default-rtdb.firebaseio.com";
const args = process.argv.slice(2);
const file = args.find(a => !a.startsWith("--"));
const dryRun = args.includes("--dry-run"), replace = args.includes("--replace");
if (!file) { console.error("Usage: node import-students.js students.csv [--dry-run] [--replace]"); process.exit(1); }

function splitCsvLine(line) {            // handles "quoted, values"
  const out = []; let cur = "", q = false;
  for (let i = 0; i < line.length; i++) {
    const c = line[i];
    if (c === '"') { if (q && line[i + 1] === '"') { cur += '"'; i++; } else q = !q; }
    else if (c === "," && !q) { out.push(cur); cur = ""; }
    else cur += c;
  }
  out.push(cur); return out.map(x => x.trim());
}

function parse(text) {
  const lines = text.replace(/^\uFEFF/, "").split(/\r?\n/).filter(l => l.trim());
  const head = splitCsvLine(lines.shift()).map(h => h.toLowerCase());
  for (const need of ["id", "route"]) if (!head.includes(need)) throw new Error("CSV needs an '" + need + "' column");
  const students = {}, errors = [];
  lines.forEach((line, n) => {
    const v = splitCsvLine(line), row = {};
    head.forEach((h, i) => row[h] = v[i] || "");
    const id = row.id.toUpperCase();
    if (!/^[A-Z0-9]{10}$/.test(id)) return errors.push(`Row ${n + 2}: ID "${row.id}" must be exactly 10 letters/numbers`);
    if (!/^r\d+$/.test(row.route)) return errors.push(`Row ${n + 2}: route "${row.route}" should look like r1, r2, r10`);
    if (students[id]) return errors.push(`Row ${n + 2}: duplicate ID ${id}`);
    const rec = { route: row.route };
    if (row.name) rec.name = row.name;
    if (row.bus) rec.bus = row.bus.toUpperCase();
    if (row.stop) rec.stop = row.stop;
    students[id] = rec;
  });
  return { students, errors };
}

(async () => {
  const { students, errors } = parse(fs.readFileSync(file, "utf8"));
  console.log(Object.keys(students).length + " valid students, " + errors.length + " problem rows.");
  errors.forEach(e => console.log("  skipped - " + e));
  if (dryRun || !Object.keys(students).length) return;

  const admin = require("firebase-admin");
  admin.initializeApp({ credential: admin.credential.cert(require("./serviceAccountKey.json")), databaseURL: DATABASE_URL });
  const ref = admin.database().ref("students");
  await (replace ? ref.set(students) : ref.update(students));
  console.log(replace ? "Roster replaced." : "Roster updated.");
  process.exit(0);
})().catch(e => { console.error("Failed: " + e.message); process.exit(1); });
