# Student ID -> bus route + number

When a student types their 10-character ID, the app looks it up and shows the assigned route and bus.

## Files
- `index.html` - updated app (front end)
- `backend/students.csv` - the roster (edit this)
- `backend/import-students.js` - uploads the roster to Firebase
- `backend/database.rules.json` - Firebase rules (paste in Realtime Database > Rules)

## Try it without a backend (demo)
Open `index.html`. With Firebase not configured it uses the sample roster in `DATA.students`.
Try `2021CSE001`, `2021ECE014`, `2022MEC027`, `2023IT0042`.

## Go live
1. Firebase console: create a Realtime Database. Paste the `FIREBASE_CONFIG` values into `index.html` (section 2).
2. Paste `database.rules.json` into the Rules tab and Publish. Students can read only one record by exact ID; the full list cannot be read or edited from the browser. Merge with your existing rules if they differ (the `buses` and `status` rules match how the app currently works).
3. In `backend/`: `npm install`, add `serviceAccountKey.json`, set `FIREBASE_DATABASE_URL`.
4. Fill `students.csv`: `id,name,route,bus,stop`. `route` must be an id from `DATA.routes` (r1..r10). `bus` and `stop` are optional; without `bus` the route's bus from `DATA.buses` is used. `stop` must match a stop name exactly.
5. `node import-students.js students.csv --dry-run`, then `node import-students.js students.csv`.

To move a student to another bus later, edit the CSV and import again. Their app updates the next time they open it.
